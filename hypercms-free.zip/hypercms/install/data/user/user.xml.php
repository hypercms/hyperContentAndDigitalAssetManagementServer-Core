<?xml version="1.0" encoding="utf-8" ?>
<userlist>
<user>
<login>admin</login>
<password></password>
<hashcode></hashcode>
<admin>1</admin>
<userdate></userdate>
<realname><![CDATA[Super User]]></realname>
<email></email>
<signature></signature>
<language>en</language>
<theme>standard</theme>
</user>
<user>
<login>hcms_download</login>
<password>cm8f4Ju0UivGk</password>
<hashcode>c2330417222067356dcf23186eccc28f</hashcode>
<admin>0</admin>
<userdate></userdate>
<realname><![CDATA[Download User]]></realname>
<email></email>
<signature></signature>
<language>en</language>
<theme>standard</theme>
</user>
</userlist>