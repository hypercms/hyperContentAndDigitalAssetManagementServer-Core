<?php
$disksite = "";
$diskkey = "server";
$diskhash = "tg3234g234zg78ze8whf";
?>