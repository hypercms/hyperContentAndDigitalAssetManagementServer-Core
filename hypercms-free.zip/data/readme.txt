This file is part of
hyper Content Management Server - http://www.hypercms.com
Copyright (c) by hyper CMS Content Management Solutions GmbH

You should have received a copy of the License along with hyperCMS.

This directory is used for the internal repository.

